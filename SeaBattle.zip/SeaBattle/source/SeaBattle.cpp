﻿#include <iostream>
#include "menu.h"

int main() {
	menu();
}