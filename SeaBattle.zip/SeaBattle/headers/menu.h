#pragma once
#ifndef _MENU_H_
#define _MENU_H_
int menu();
void GotoXY(int X, int Y);
#endif // !_MENU_H_

