#pragma once
#ifndef _NEW_GAME_MENU_H_
#define _NEW_GAME_MENU_H_
int newGameMenu();
#endif // !_NEW_GAME_MENU_H_
