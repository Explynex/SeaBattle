#pragma once
#ifndef _AI_H_
#define _AI_H_
void AI();
void aiPlayer();
void fieldBoarder();
void hitShip(int x, int y);
void shipAdd();
void shipDrown(int shipNum);
void shipOnfire();
void showField();
void kletochki(int i);
void horOutput(int i);
void GotoXY(int X, int Y);
#endif // !_AI_H_
