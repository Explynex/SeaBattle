#pragma once
#ifndef _GOTO_XY_H_
#define _GOTO_XY_H_
void GotoXY(int X, int Y);
#endif // !_GOTO_XY_H_



